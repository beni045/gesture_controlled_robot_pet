import random
import os
import cv2
import numpy as np
import argparse
import sys
sys.path.append('..')
from model_processor import handpose_ModelProcessor
from model_processor import face_detection_ModelProcessor
from model_processor import hand_detection_ModelProcessor
from atlas_utils.camera import Camera
from atlas_utils import presenteragent
from atlas_utils.acl_image import AclImage
import acl
from acl_resource import AclResource


MODEL_PATH_HAND_POSE = "../model/handpose_argmax_bgr.om"
MODEL_PATH_FACE_DETECTION = "../model/face_detection.om"
MODEL_PATH_HAND_DETECTION = "../model/Hand_detection.om"
BODYPOSE_CONF="../param.conf"
CAMERA_FRAME_WIDTH = 1280
CAMERA_FRAME_HEIGHT = 720

def execute(model_path):

    ## Initialization ##
    #initialize acl runtime 
    acl_resource = AclResource()
    acl_resource.init()


    ## Prepare Model ##
    # parameters for model path and model inputs
    handpose_model_parameters = {
        'model_dir': model_path,
        'width': 256, # model input width      
        'height': 256, # model input height
    }

    hand_detection_model_parameters = {
        'model_dir': MODEL_PATH_HAND_DETECTION,
    }

    face_detection_model_parameters = {
        'model_dir': MODEL_PATH_FACE_DETECTION,
    }

    # perpare model instance: init (loading model from file to memory)
    # model_processor: preprocessing + model inference + postprocessing
    handpose_model_processor = handpose_ModelProcessor(acl_resource, handpose_model_parameters)

    hand_detection_model_processor = hand_detection_ModelProcessor(acl_resource, hand_detection_model_parameters)
    face_detection_model_processor = face_detection_ModelProcessor(acl_resource, face_detection_model_parameters)
    
    ## Get Input ##
    # Initialize Camera
    cap = Camera(id = 0, fps = 10)

    ## Set Output ##
    # open the presenter channel
    chan = presenteragent.presenter_channel.open_channel(BODYPOSE_CONF)
    if chan == None:
        print("Open presenter channel failed")
        return



    while True:
        ## Read one frame from Camera ## 
        img_original = cap.read()
        if not img_original:
            print('Error: Camera read failed')
            break
        # Camera Input (YUV) to BGR Image
        image_byte = img_original.tobytes()
        image_array = np.frombuffer(image_byte, dtype=np.uint8)
        img_original = YUVtoRGB(image_array)
        img_original = cv2.flip(img_original,1)
        
        ## Model Prediction ##
        # model_processor.predict: processing + model inference + postprocessing
        # canvas: the picture overlayed with human body joints and limbs
        canvas1 = hand_detection_model_processor.predict(img_original)
        canvas2 = face_detection_model_processor.predict(canvas1)
        canvas = handpose_model_processor.predict(canvas2)
        #canvas1 = cv2.cvtColor(canvas1, cv2.COLOR_BGR2RGB, 3)
        
        canvas = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB, 3)
        
        ## Present Result ##
        # convert to jpeg image for presenter server display
        _,jpeg_image = cv2.imencode('.jpg',canvas)
        # construct AclImage object for presenter server
        jpeg_image = AclImage(jpeg_image, img_original.shape[0], img_original.shape[1], jpeg_image.size)
        # send to presenter server
        chan.send_detection_data(img_original.shape[0], img_original.shape[1], jpeg_image, [])

    # release the resources
    cap.release()


def YUVtoRGB(byteArray):
    e = 1280*720
    Y = byteArray[0:e]
    Y = np.reshape(Y, (720,1280))

    s = e
    V = byteArray[s::2]
    V = np.repeat(V, 2, 0)
    V = np.reshape(V, (360,1280))
    V = np.repeat(V, 2, 0)

    U = byteArray[s+1::2]
    U = np.repeat(U, 2, 0)
    U = np.reshape(U, (360,1280))
    U = np.repeat(U, 2, 0)

    RGBMatrix = (np.dstack([Y,U,V])).astype(np.uint8)
    RGBMatrix = cv2.cvtColor(RGBMatrix, cv2.COLOR_YUV2RGB, 3)
    RGBMatrix = cv2.cvtColor(RGBMatrix, cv2.COLOR_RGB2BGR) 
    return RGBMatrix
   

if __name__ == '__main__':   

    description = 'Load a model for handpose'
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--model', type=str, default=MODEL_PATH_HAND_POSE)
    args = parser.parse_args()

    execute(args.model)
